import { applyPlayerAction } from '@/lib/game';
import { cleanCode, err, json, readBody } from '@/lib/http';
import { loadGame, savePlayers } from '@/lib/store';

export const dynamic = 'force-dynamic';

export async function POST(req: Request, { params }: { params: Promise<{ code: string }> }) {
  const code = cleanCode((await params).code);
  const body = await readBody(req);
  const { meta, players } = await loadGame(code);
  if (!meta) return err('No game with that code.', 404);
  const me = players.find((p) => p.token === body.token);
  if (!me) return err('Not in this game.', 401);
  const e = applyPlayerAction(meta, players, me, body);
  if (e) return err(e);
  await savePlayers(code, [me]);
  return json({ ok: true });
}
