import { applyHostAction } from '@/lib/game';
import { cleanCode, err, json, readBody } from '@/lib/http';
import { loadGame, removePlayer, saveMeta, savePlayers } from '@/lib/store';

export const dynamic = 'force-dynamic';

export async function POST(req: Request, { params }: { params: Promise<{ code: string }> }) {
  const code = cleanCode((await params).code);
  const body = await readBody(req);
  const { meta, players } = await loadGame(code);
  if (!meta) return err('No game with that code.', 404);
  if (body.hostToken !== meta.hostToken) return err('Not the host.', 401);
  const r = applyHostAction(meta, players, body);
  if (r.error) return err(r.error);
  if (r.remove) await removePlayer(code, r.remove);
  await savePlayers(code, r.save);
  await saveMeta(meta);
  return json({ ok: true });
}
