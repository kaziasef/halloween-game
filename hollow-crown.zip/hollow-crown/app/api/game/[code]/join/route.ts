import { MAX_PLAYERS, newPlayer } from '@/lib/game';
import { cleanCode, err, json, readBody } from '@/lib/http';
import { loadGame, savePlayers } from '@/lib/store';

export const dynamic = 'force-dynamic';

export async function POST(req: Request, { params }: { params: Promise<{ code: string }> }) {
  const code = cleanCode((await params).code);
  const body = await readBody(req);
  const name = String(body.name ?? '').trim().replace(/\s+/g, ' ').slice(0, 24);
  const costume = String(body.costume ?? '').trim().replace(/\s+/g, ' ').slice(0, 40);
  if (!name) return err('Enter your name.');
  const { meta, players } = await loadGame(code);
  if (!meta) return err('No game with that code.', 404);
  if (meta.phase === 'results') return err('This game has finished.');
  if (players.length >= MAX_PLAYERS) return err('This game is full.');
  if (players.some((p) => p.name.toLowerCase() === name.toLowerCase()))
    return err('That name is taken. Add an initial or a nickname.');
  const p = newPlayer(name, costume);
  await savePlayers(code, [p]);
  return json({ playerId: p.id, token: p.token, lateArrival: meta.phase !== 'lobby' });
}
