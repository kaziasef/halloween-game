import { hostView, playerView } from '@/lib/game';
import { cleanCode, err, json } from '@/lib/http';
import { loadGame, storageMode } from '@/lib/store';

export const dynamic = 'force-dynamic';

export async function GET(req: Request, { params }: { params: Promise<{ code: string }> }) {
  const code = cleanCode((await params).code);
  const { meta, players } = await loadGame(code);
  if (!meta) return err('No game with that code.', 404);
  const host = req.headers.get('x-host');
  if (host) {
    if (host !== meta.hostToken) return err('Not the host.', 401);
    return json(hostView(meta, players, storageMode));
  }
  const token = req.headers.get('x-token');
  const me = token ? players.find((p) => p.token === token) : undefined;
  if (!me) return err('Not in this game.', 401);
  return json(playerView(meta, players, me));
}
