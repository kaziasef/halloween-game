import { makeCode, newMeta } from '@/lib/game';
import { err, json } from '@/lib/http';
import { gameExists, saveMeta } from '@/lib/store';

export const dynamic = 'force-dynamic';

export async function POST() {
  for (let i = 0; i < 8; i++) {
    const code = makeCode();
    if (await gameExists(code)) continue;
    const hostToken = crypto.randomUUID();
    await saveMeta(newMeta(code, hostToken));
    return json({ code, hostToken });
  }
  return err('Could not create a game. Try again.', 500);
}
