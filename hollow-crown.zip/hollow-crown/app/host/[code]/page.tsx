'use client';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import QRCode from 'qrcode';
import { useEffect, useState, type ReactNode } from 'react';
import { Countdown, Elapsed } from '@/components/Clock';
import { post, store, usePoll } from '@/lib/client';
import { PHASE_LABEL } from '@/lib/copy';
import type { HostView, PublicPlayer } from '@/lib/types';

const MIN = 5;
const RECOMMENDED = 10;
const hunterCount = (n: number) => (n >= 10 ? Math.max(2, Math.round(n / 5)) : 1);

export default function HostPage() {
  const params = useParams<{ code: string }>();
  const code = String(params.code || '').toUpperCase();
  const key = `hc_host_${code}`;
  const [token, setToken] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const fromHash = new URLSearchParams(window.location.hash.slice(1)).get('k');
    if (fromHash) {
      store(key, fromHash);
      history.replaceState(null, '', window.location.pathname);
    }
    setToken(store(key));
    setReady(true);
  }, [key]);

  if (!ready) return <main className="wrap muted">Lighting candles…</main>;
  if (!token)
    return (
      <main className="wrap stack">
        <h1>Not the host</h1>
        <p className="muted">This device isn&apos;t the host for room {code}. Use the private host link from the host&apos;s device.</p>
        <Link className="btn" href={`/play/${code}`}>Join as a player instead</Link>
      </main>
    );
  return <HostGame code={code} token={token} />;
}

function HostGame({ code, token }: { code: string; token: string }) {
  const { data, status, offline, refresh } = usePoll<HostView>(`/api/game/${code}/state`, { 'x-host': token }, 2500);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [qr, setQr] = useState<string>('');
  const [origin, setOrigin] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const o = window.location.origin;
    setOrigin(o);
    QRCode.toDataURL(`${o}/play/${code}`, { margin: 1, width: 520, color: { dark: '#0b0910', light: '#eee8f4' } })
      .then(setQr)
      .catch(() => {});
  }, [code]);

  if (status === 401)
    return (
      <main className="wrap stack">
        <h1>Not the host</h1>
        <p className="muted">The saved host key doesn&apos;t match room {code}.</p>
      </main>
    );
  if (status === 404)
    return (
      <main className="wrap stack">
        <h1>No such party</h1>
        <p className="muted">Room {code} doesn&apos;t exist or has expired.</p>
        <Link className="btn" href="/">Back to start</Link>
      </main>
    );
  if (!data) return <main className="wrap muted">Lighting candles…</main>;

  const v = data;
  const ph = v.phase;
  const offset = v.serverNow - (v._clientAt ?? Date.now());
  const n = v.inGameCount;
  const nameOf = (id: string) => v.players.find((p) => p.id === id);
  const joinUrl = `${origin}/play/${code}`;

  async function act(type: string, extra: Record<string, unknown> = {}, confirmMsg?: string) {
    if (confirmMsg && !confirm(confirmMsg)) return;
    setBusy(true);
    setError(null);
    const r = await post(`/api/game/${code}/host`, { hostToken: token, type, ...extra });
    setBusy(false);
    if (!r.ok) setError(r.error ?? 'Something went wrong.');
    await refresh();
  }

  const Next = ({ type, label, warn, disabled }: { type: string; label: string; warn?: string; disabled?: boolean }) => (
    <button className="block" disabled={busy || disabled} onClick={() => act(type, {}, warn)}>
      {label}
    </button>
  );

  return (
    <main className="wrap wide stack">
      <div className="topbar">
        <Link href="/" className="brand">THE HOLLOW CROWN · HOST</Link>
        <span className={`pill live ${offline ? 'off' : ''}`}>{offline ? 'Reconnecting' : PHASE_LABEL[ph]}</span>
      </div>

      {v.storage === 'memory' && (
        <div className="error">
          Storage isn&apos;t connected, so the game is running in temporary memory. That works locally but will lose
          state on Vercel. Add Upstash Redis to the project (see README) before the party.
        </div>
      )}
      {error && <div className="error">{error}</div>}

      <div className="grid2">
        <div className="stack">
          {/* ---------- main control ---------- */}
          {ph === 'lobby' && (
            <section className="card stack glow">
              <div className="eyebrow">Room code</div>
              <div className="code-big">{code}</div>
              {qr && <img className="qr" src={qr} alt={`QR code to join room ${code}`} />}
              <p className="center muted small">{joinUrl}</p>
              <hr className="hr" />
              <div className="spread">
                <span>{v.players.length} joined</span>
                <span className="muted small">
                  Will deal {hunterCount(v.players.length)} Hunter{hunterCount(v.players.length) === 1 ? '' : 's'} · curse target {hunterCount(v.players.length)}
                </span>
              </div>
              {v.players.length < RECOMMENDED && (
                <p className="faint small">
                  Best with {RECOMMENDED}+ players (designed for 20). {v.players.length < MIN ? `Minimum ${MIN} to deal.` : 'Small games work for testing.'}
                </p>
              )}
              <Next
                type="deal"
                label="Deal roles & start Round 1"
                disabled={v.players.length < MIN}
                warn={`Deal roles to all ${v.players.length} players? Anyone joining after this only plays the costume contest.`}
              />
            </section>
          )}

          {ph === 'round1' && (
            <Stage title="Round 1 in progress" timer={<Elapsed since={v.phaseStartedAt} offset={offset} />} hint="Aim for 30 to 45 minutes.">
              <Next type="midpoint" label="Call the midpoint toast" warn="Close mission one and call the midpoint toast?" />
            </Stage>
          )}

          {ph === 'midpoint' && (
            <Stage title="Midpoint toast">
              {v.midpointCurses === null ? (
                <>
                  <Counter label="Slips sealed" value={v.counts.sealed1} total={n} />
                  <Next
                    type="count"
                    label="Count the curses"
                    warn={v.counts.sealed1 < n ? `Only ${v.counts.sealed1} of ${n} have sealed. Unsealed players are counted by their current mission status. Count now?` : undefined}
                  />
                </>
              ) : (
                <>
                  <div className="center stack">
                    <p className="muted">Curses at the midpoint</p>
                    <div className="big-number">{v.midpointCurses}</div>
                    <p className="muted small">of {v.threshold} the Hunters need</p>
                  </div>
                  <Next type="round2" label="Open Round 2 & soul readings" />
                </>
              )}
            </Stage>
          )}

          {ph === 'round2' && (
            <Stage title="Round 2 in progress" timer={<Elapsed since={v.phaseStartedAt} offset={offset} />} hint="Soul readings are open. Start the finale at the costume gathering.">
              <Next type="finale" label="Start the finale" warn="Close mission two and all soul readings?" />
            </Stage>
          )}

          {ph === 'finale' && (
            <Stage title="Finale">
              <Counter label="Second slips sealed" value={v.counts.sealed2} total={n} />
              {v.discussionEndsAt ? (
                <div className="center">
                  <div className="eyebrow">Discussion</div>
                  <Countdown endsAt={v.discussionEndsAt} offset={offset} />
                </div>
              ) : (
                <button className="block ghost" disabled={busy} onClick={() => act('discussion')}>
                  Start 3-minute discussion
                </button>
              )}
              <Next
                type="nominate"
                label="Open nominations"
                warn={v.counts.sealed2 < n ? `Only ${v.counts.sealed2} of ${n} have sealed. Mission two locks now. Continue?` : undefined}
              />
            </Stage>
          )}

          {ph === 'nominate' && (
            <Stage title="Nominations">
              <Counter label="Nominations in" value={v.counts.nominated} total={n} />
              <Next
                type="tally"
                label="Tally the suspects"
                warn={v.counts.nominated < n ? `Only ${v.counts.nominated} of ${n} have nominated. Tally now?` : undefined}
              />
            </Stage>
          )}

          {ph === 'runoff' && v.runoff && (
            <Stage title="Suspect runoff" hint={`Tie for the last ${v.runoff.slots === 1 ? 'place' : `${v.runoff.slots} places`}. Players pick from the tied names only.`}>
              {v.runoff.chosen.length > 0 && (
                <p className="small">Already suspects: <b>{v.runoff.chosen.map((id) => nameOf(id)?.name).join(', ')}</b></p>
              )}
              <p className="small">Tied: <b>{v.runoff.candidates.map((id) => nameOf(id)?.name).join(', ')}</b></p>
              <Counter label="Runoff picks in" value={v.counts.runoffPicked} total={n} />
              <Next type="tallyRunoff" label="Tally the runoff" />
            </Stage>
          )}

          {ph === 'suspects' && v.suspects && (
            <Stage title="The three suspects">
              <Names players={v.suspects.map((id) => nameOf(id)!).filter(Boolean)} />
              {v.notes.length > 0 && <p className="faint small">{v.notes.join(' ')}</p>}
              <Next type="reveal" label="Reveal all roles & the result" />
            </Stage>
          )}

          {ph === 'reveal' && <HostReveal view={v} onNext={() => act('vote')} busy={busy} />}

          {ph === 'vote' && (
            <Stage title="Costume vote">
              <Counter label="Votes cast" value={v.counts.voted} total={v.players.length} />
              <Next
                type="crown"
                label="Crown the costume"
                warn={v.counts.voted < v.players.length ? `Only ${v.counts.voted} of ${v.players.length} have voted. Crown now?` : undefined}
              />
            </Stage>
          )}

          {ph === 'costumeRunoff' && v.costumeRunoff && (
            <Stage title="Costume runoff" hint="Tie for the crown. Everyone picks one of the tied costumes.">
              <Names players={v.costumeRunoff.map((id) => nameOf(id)!).filter(Boolean)} />
              <Counter label="Runoff votes in" value={v.counts.costumeRunoffPicked} total={v.players.length} />
              <Next type="crownRunoff" label="Crown the winner" />
            </Stage>
          )}

          {ph === 'results' && (
            <section className="card banner glow">
              <div style={{ fontSize: '3.5rem' }}>👑</div>
              <div className="eyebrow">Crowned tonight</div>
              <h1 className="gold">{nameOf(v.crowned ?? '')?.name}</h1>
              <p className="muted">{nameOf(v.crowned ?? '')?.costume}</p>
              {v.notes.length > 0 && <p className="faint small">{v.notes.join(' ')}</p>}
            </section>
          )}

          <Script view={v} />
        </div>

        {/* ---------- side ---------- */}
        <div className="stack">
          <section className="card stack">
            <div className="spread">
              <div className="eyebrow">Guests ({v.players.length})</div>
              {ph !== 'lobby' && <span className="faint small">{n} in the game</span>}
            </div>
            <ul className="plist">
              {v.players.map((p) => (
                <li key={p.id}>
                  <div className="who">
                    <b>{p.name}</b>
                    <span>{p.costume || ' '}</span>
                  </div>
                  {ph === 'results' && v.costumeTally ? (
                    <b className="gold">{v.costumeTally[p.id] ?? 0}</b>
                  ) : !p.inGame && ph !== 'lobby' ? (
                    <span className="badge neutral">Costume only</span>
                  ) : null}
                  {!p.inGame && (
                    <button
                      className="mini ghost"
                      disabled={busy}
                      onClick={() => act('kick', { id: p.id }, `Remove ${p.name}?`)}
                    >
                      Remove
                    </button>
                  )}
                </li>
              ))}
              {v.players.length === 0 && <li className="muted">Nobody yet. Share the QR code.</li>}
            </ul>
            {ph !== 'lobby' && ph !== 'results' && (
              <p className="faint small">Late arrivals can still scan the code and join the costume contest.</p>
            )}
          </section>

          <section className="card stack">
            <div className="eyebrow">Host tools</div>
            <Link className="btn block ghost" href={`/play/${code}`} target="_blank">
              Play too (opens player view)
            </Link>
            <button
              className="block ghost"
              onClick={async () => {
                const link = `${origin}/host/${code}#k=${token}`;
                try {
                  await navigator.clipboard.writeText(link);
                  setCopied(true);
                  setTimeout(() => setCopied(false), 2000);
                } catch {
                  prompt('Copy this private host link', link);
                }
              }}
            >
              {copied ? 'Copied' : 'Copy private host link'}
            </button>
            <p className="faint small">
              Open the host link on a laptop to cast this screen to a TV. Keep it private: it controls the game. The host
              screen never shows roles before the reveal.
            </p>
            <Link href="/rules" className="small">Rules</Link>
          </section>
        </div>
      </div>
    </main>
  );
}

function Stage({ title, timer, hint, children }: { title: string; timer?: ReactNode; hint?: string; children: ReactNode }) {
  return (
    <section className="card stack glow">
      <div className="spread">
        <h2>{title}</h2>
        {timer}
      </div>
      {hint && <p className="muted small">{hint}</p>}
      {children}
    </section>
  );
}

function Counter({ label, value, total }: { label: string; value: number; total: number }) {
  return (
    <div className="stack" style={{ gap: 6 }}>
      <div className="spread">
        <span className="muted small">{label}</span>
        <b>
          {value} / {total}
        </b>
      </div>
      <div className="progress">
        <i style={{ width: `${total ? (value / total) * 100 : 0}%` }} />
      </div>
    </div>
  );
}

function Names({ players }: { players: PublicPlayer[] }) {
  return (
    <ul className="plist">
      {players.map((p) => (
        <li key={p.id}>
          <div className="who">
            <b>{p.name}</b>
            <span>{p.costume || ' '}</span>
          </div>
        </li>
      ))}
    </ul>
  );
}

function HostReveal({ view, onNext, busy }: { view: HostView; onNext: () => void; busy: boolean }) {
  const rows = view.reveal ?? [];
  const roleOf = (id: string) => rows.find((r) => r.id === id)?.role;
  const name = (id: string) => view.players.find((p) => p.id === id);
  const total = (view.midpointCurses ?? 0) + (view.finaleCurses ?? 0);
  const caught = (view.suspects ?? []).filter((id) => roleOf(id) === 'hunter').length;
  return (
    <>
      <section className={`card banner ${view.winner}`}>
        <div className="eyebrow">The crown belongs to</div>
        <h1 className={view.winner === 'hunters' ? 'blood' : 'violet'}>
          {view.winner === 'hunters' ? 'The Hunters' : 'The Monsters'}
        </h1>
        <p className="muted">
          {total} curse{total === 1 ? '' : 's'} of {view.threshold} needed · {caught} Hunter{caught === 1 ? '' : 's'} among the suspects
        </p>
      </section>
      <section className="card stack">
        <div className="eyebrow">Suspects</div>
        <ul className="plist">
          {(view.suspects ?? []).map((id) => (
            <li key={id}>
              <div className="who"><b>{name(id)?.name}</b><span>{name(id)?.costume || ' '}</span></div>
              <span className={`badge ${roleOf(id)}`}>{roleOf(id)}</span>
            </li>
          ))}
        </ul>
        <div className="eyebrow">Hunters</div>
        <ul className="plist">
          {rows.filter((r) => r.role === 'hunter').map((r) => (
            <li key={r.id}>
              <div className="who"><b>{name(r.id)?.name}</b><span>{name(r.id)?.costume || ' '}</span></div>
              <span className="badge hunter">{r.missions} curse{r.missions === 1 ? '' : 's'}</span>
            </li>
          ))}
        </ul>
        <p className="faint small">
          Midpoint {view.midpointCurses ?? 0} + finale {view.finaleCurses ?? 0} = {total}. Hunters can confirm their
          mission count matches.
        </p>
        <button className="block" disabled={busy} onClick={onNext}>
          Open costume voting
        </button>
      </section>
    </>
  );
}

function Script({ view }: { view: HostView }) {
  const h = view.hunters || hunterCount(view.players.length);
  const lines: Partial<Record<HostView['phase'], string>> = {
    lobby: `Once everyone has arrived, gather them for three minutes: "Monsters have gathered to crown the best costume, but ${h} hidden Hunter${h === 1 ? ' is' : 's are'} trying to curse the coronation. Scan the code and join with your name and costume. When I deal, hold your cards to see your allegiance and mission one. Complete it while you mingle. Keep your screen to yourself. Nobody is eliminated."`,
    round1:
      'Let the party run. Missions happen in normal conversation; nobody stops the music. Call the midpoint at a natural drinks or snack break.',
    midpoint:
      '"Mission one is closed. Check your status, then tap Seal my slip. Everyone taps the same button." When most have sealed, count the curses and read the number aloud. Then: "Mission two is open, and soul readings are now available." Any drink counts; drinking is never required.',
    round2:
      'Mingle for another 30 to 45 minutes. Start the finale when everyone gathers for costumes.',
    finale:
      '"Mission two and all readings are closed. Seal your second slip." Start the three-minute discussion: accusations, defences, reading claims. Nobody has to speak. Then open nominations.',
    nominate: '"Secretly pick three other players you think are Hunters."',
    runoff: '"We have a tie. Pick from the tied names only."',
    suspects: 'Read the three suspects aloud. Then reveal every role.',
    reveal:
      'Keep the reveal brief and save the "you made me do that!" stories for later. Give each costume a quick entrance or pose, then open the vote.',
    vote: '"Cast your costume votes. Your phone knows how many you have. No self-votes, max three per costume."',
    costumeRunoff: '"It\'s a tie. One vote each for the tied costumes."',
    results: 'Crown them.',
  };
  const line = lines[view.phase];
  if (!line) return null;
  return (
    <section className="card say stack">
      <div className="eyebrow">Say this</div>
      <p>{line}</p>
    </section>
  );
}
