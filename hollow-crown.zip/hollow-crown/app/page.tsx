'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { post, store } from '@/lib/client';

export default function Home() {
  const router = useRouter();
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function host() {
    setBusy(true);
    setError(null);
    const r = (await post('/api/game', {})) as { ok: boolean; error?: string; code?: string; hostToken?: string };
    setBusy(false);
    if (!r.ok || !r.code || !r.hostToken) return setError(r.error ?? 'Could not create a game.');
    store(`hc_host_${r.code}`, r.hostToken);
    router.push(`/host/${r.code}`);
  }

  const clean = code.toUpperCase().replace(/[^A-Z]/g, '').slice(0, 4);

  return (
    <main className="wrap stack">
      <div className="hero stack">
        <div className="crown" aria-hidden>👑</div>
        <div className="eyebrow">A Halloween game of secret missions</div>
        <h1>The Hollow Crown</h1>
        <p className="muted">
          The creatures of the night gather to crown the best costume. Hidden Hunters have slipped into the party to
          curse the crown. Mingle, complete secret missions, and work out who is turning the night against you.
        </p>
      </div>

      <form
        className="card stack"
        onSubmit={(e) => {
          e.preventDefault();
          if (clean.length === 4) router.push(`/play/${clean}`);
        }}
      >
        <h2>Join a game</h2>
        <div>
          <label htmlFor="code">Room code</label>
          <input
            id="code"
            className="code-input"
            value={clean}
            onChange={(e) => setCode(e.target.value)}
            placeholder="ABCD"
            autoCapitalize="characters"
            autoComplete="off"
            inputMode="text"
          />
        </div>
        <button className="block" disabled={clean.length !== 4}>
          Enter the party
        </button>
      </form>

      <div className="card stack">
        <h2>Host a game</h2>
        <p className="muted small">
          You get a room code and a QR code. Your phone becomes the control screen. You can still play: the host screen
          never shows roles.
        </p>
        {error && <div className="error">{error}</div>}
        <button className="block ghost" onClick={host} disabled={busy}>
          {busy ? 'Opening the crypt…' : 'Create a game'}
        </button>
      </div>

      <div className="footer-links">
        <Link href="/rules">How to play</Link>
      </div>
    </main>
  );
}
