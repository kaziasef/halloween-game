'use client';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import HoldReveal from '@/components/HoldReveal';
import { Countdown } from '@/components/Clock';
import { post, store, usePoll } from '@/lib/client';
import { PHASE_LABEL, atOrAfter, roleText } from '@/lib/copy';
import { MISSION_RULES, type Mission } from '@/lib/missions';
import type { PlayerView, PublicPlayer } from '@/lib/types';

type Act = (type: string, extra?: Record<string, unknown>) => Promise<boolean>;

export default function PlayPage() {
  const params = useParams<{ code: string }>();
  const code = String(params.code || '').toUpperCase();
  const key = `hc_player_${code}`;
  const [token, setToken] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setToken(store(key));
    setReady(true);
  }, [key]);

  if (!ready) return <main className="wrap muted">Summoning…</main>;
  if (!token)
    return (
      <JoinForm
        code={code}
        onJoined={(t) => {
          store(key, t);
          setToken(t);
        }}
      />
    );
  return (
    <Game
      code={code}
      token={token}
      onLost={() => {
        store(key, null);
        setToken(null);
      }}
    />
  );
}

/* ---------------- join ---------------- */

function JoinForm({ code, onJoined }: { code: string; onJoined: (t: string) => void }) {
  const [name, setName] = useState('');
  const [costume, setCostume] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function join(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const r = (await post(`/api/game/${code}/join`, { name, costume })) as { ok: boolean; error?: string; token?: string };
    setBusy(false);
    if (!r.ok || !r.token) return setError(r.error ?? 'Could not join.');
    onJoined(r.token);
  }

  return (
    <main className="wrap stack">
      <div className="topbar">
        <Link href="/" className="brand">THE HOLLOW CROWN</Link>
        <span className="pill">Room {code}</span>
      </div>
      <div className="hero stack">
        <div className="crown" aria-hidden>👑</div>
        <h1>Enter the party</h1>
        <p className="muted">Use the name people know you by tonight. Your costume name is what others will vote for.</p>
      </div>
      <form className="card stack" onSubmit={join}>
        <div>
          <label htmlFor="name">Your name</label>
          <input id="name" value={name} onChange={(e) => setName(e.target.value)} maxLength={24} autoComplete="given-name" placeholder="e.g. Asef" />
        </div>
        <div>
          <label htmlFor="costume">Your costume / character</label>
          <input id="costume" value={costume} onChange={(e) => setCostume(e.target.value)} maxLength={40} placeholder="e.g. Vampire accountant" />
        </div>
        {error && <div className="error">{error}</div>}
        <button className="block" disabled={busy || !name.trim()}>
          {busy ? 'Joining…' : 'Join'}
        </button>
      </form>
      <div className="footer-links">
        <Link href="/rules">How to play</Link>
      </div>
    </main>
  );
}

/* ---------------- game ---------------- */

function Game({ code, token, onLost }: { code: string; token: string; onLost: () => void }) {
  const { data, status, offline, refresh } = usePoll<PlayerView>(`/api/game/${code}/state`, { 'x-token': token });
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (status === 401) onLost();
  }, [status, onLost]);

  if (status === 404)
    return (
      <main className="wrap stack">
        <h1>No such party</h1>
        <p className="muted">Room {code} doesn&apos;t exist or has expired.</p>
        <Link className="btn" href="/">Back to start</Link>
      </main>
    );
  if (!data) return <main className="wrap muted">Summoning…</main>;

  const act: Act = async (type, extra = {}) => {
    setBusy(true);
    setError(null);
    const r = await post(`/api/game/${code}/action`, { token, type, ...extra });
    setBusy(false);
    if (!r.ok) setError(r.error ?? 'Something went wrong.');
    await refresh();
    return r.ok;
  };

  const v = data;
  const me = v.me;
  const offset = v.serverNow - (v._clientAt ?? Date.now());
  const nameOf = (id: string) => v.players.find((p) => p.id === id);
  const inGame = !!me.role;
  const ph = v.phase;

  return (
    <main className="wrap stack">
      <div className="topbar">
        <Link href="/" className="brand">THE HOLLOW CROWN</Link>
        <span className={`pill live ${offline ? 'off' : ''}`}>{offline ? 'Reconnecting' : PHASE_LABEL[ph]}</span>
      </div>

      <div className="spread">
        <div>
          <div className="display" style={{ fontSize: '1.3rem' }}>{me.name}</div>
          <div className="muted small">{me.costume || 'No costume name'}</div>
        </div>
        <span className="pill">Room {v.code}</span>
      </div>

      {error && <div className="error">{error}</div>}

      {ph === 'lobby' && (
        <section className="card stack">
          <h2>You&apos;re in.</h2>
          <p className="muted">Waiting for the host to deal roles. {v.players.length} guests have arrived.</p>
          <PlayerList players={v.players} />
        </section>
      )}

      {ph !== 'lobby' && !inGame && (
        <div className="notice">
          You arrived after the roles were dealt, so you&apos;re not in the hidden-role game. You&apos;re still in the
          costume contest and get 3 votes at the end.
        </div>
      )}

      {inGame && (
        <>
          <section className="card stack">
            <div className="eyebrow">Your secret allegiance</div>
            <HoldReveal label="Hold to see your allegiance">
              <div className={`role-name ${me.role}`}>{roleText(me.role!, v.threshold).title}</div>
              <p className="small">{roleText(me.role!, v.threshold).body}</p>
              <p className="small faint">
                {v.hunters} Hunter{v.hunters === 1 ? '' : 's'} among {v.inGameCount} players.
              </p>
            </HoldReveal>
          </section>

          <MissionBlock
            round={1}
            mission={me.r1}
            pair={me.pair}
            done={me.m1Done}
            guests={me.m1Guests}
            editable={me.can.m1}
            closedNote={atOrAfter(ph, 'midpoint') && !me.can.m1 ? 'Mission one is closed.' : null}
            act={act}
            busy={busy}
          />
          {me.r2 ? (
            <MissionBlock
              round={2}
              mission={me.r2}
              pair={me.pair}
              done={me.m2Done}
              guests={me.m2Guests}
              editable={me.can.m2}
              closedNote={atOrAfter(ph, 'nominate') ? 'Mission two is closed.' : null}
              lockUndo={!!me.reading && !me.m1Done}
              act={act}
              busy={busy}
            />
          ) : (
            <section className="card">
              <div className="eyebrow">Round 2 mission</div>
              <p className="muted small">Unlocks after the midpoint toast.</p>
            </section>
          )}

          <Chips view={v} />

          {me.reading && (
            <section className="card stack">
              <div className="eyebrow">Your soul reading</div>
              <HoldReveal label="Hold to see what you learned">
                <p className="muted small">You read the soul of</p>
                <div className="display" style={{ fontSize: '1.4rem' }}>{me.reading.targetName}</div>
                <div className={`role-name ${me.reading.role}`}>{me.reading.role === 'hunter' ? 'Hunter' : 'Monster'}</div>
                <p className="small faint">You may tell the truth or lie about what you saw.</p>
              </HoldReveal>
            </section>
          )}
        </>
      )}

      {/* phase panels */}
      {inGame && ph === 'round1' && (
        <p className="muted small center">Mingle. The midpoint toast comes at a natural drinks or snack break.</p>
      )}

      {inGame && ph === 'midpoint' && (
        <SealPanel
          round={1}
          sealed={me.sealed1}
          canSeal={me.can.seal1}
          count={v.midpointCurses}
          act={act}
          busy={busy}
        />
      )}

      {inGame && ph === 'round2' && <ReadingPanel view={v} act={act} busy={busy} />}

      {inGame && ph === 'finale' && (
        <>
          <SealPanel round={2} sealed={me.sealed2} canSeal={me.can.seal2} count={null} act={act} busy={busy} />
          {v.discussionEndsAt && (
            <section className="card center stack">
              <div className="eyebrow">Discussion</div>
              <Countdown endsAt={v.discussionEndsAt} offset={offset} />
              <p className="muted small">Accusations, defences, claims about readings. Nobody has to speak.</p>
            </section>
          )}
        </>
      )}

      {inGame && ph === 'nominate' && (
        <PickPanel
          key="nominate"
          title="Name three suspects"
          intro="Secretly pick three other players you think are Hunters."
          options={v.players.filter((p) => p.inGame && p.id !== me.id)}
          count={Math.min(3, v.inGameCount - 1)}
          current={me.nominations}
          busy={busy}
          onSubmit={(ids) => act('nominate', { ids })}
        />
      )}
      {!inGame && ph === 'nominate' && <Waiting text="The players are naming their suspects." />}

      {ph === 'runoff' && v.runoff && inGame && (
        <PickPanel
          key="runoff"
          title="Suspect runoff"
          intro={`Tie at the cutoff. Pick ${v.runoff.slots} from the tied players only.${
            v.runoff.chosen.length ? ` Already suspects: ${v.runoff.chosen.map((id) => nameOf(id)?.name).join(', ')}.` : ''
          }`}
          options={v.runoff.candidates.filter((id) => id !== me.id).map((id) => nameOf(id)!).filter(Boolean)}
          count={Math.min(v.runoff.slots, v.runoff.candidates.filter((id) => id !== me.id).length)}
          current={me.runoffPicks}
          busy={busy}
          onSubmit={(ids) => act('runoff', { ids })}
        />
      )}

      {ph === 'suspects' && v.suspects && (
        <section className="card stack glow">
          <div className="eyebrow">The three suspects</div>
          <PlayerList players={v.suspects.map((id) => nameOf(id)!).filter(Boolean)} />
          <p className="muted small">Waiting for the host to reveal every role.</p>
        </section>
      )}

      {atOrAfter(ph, 'reveal') && <RevealPanel view={v} />}

      {ph === 'vote' && <VotePanel view={v} act={act} busy={busy} />}

      {ph === 'costumeRunoff' && v.costumeRunoff && (
        <PickPanel
          key="costumeRunoff"
          title="Costume runoff"
          intro="It's a tie for the crown. Pick one of the tied costumes."
          options={v.costumeRunoff.filter((id) => id !== me.id).map((id) => nameOf(id)!).filter(Boolean)}
          count={1}
          current={me.costumeRunoffPick ? [me.costumeRunoffPick] : null}
          busy={busy}
          onSubmit={(ids) => act('costumeRunoff', { id: ids[0] })}
        />
      )}

      {ph === 'results' && <Results view={v} />}

      {inGame && atOrAfter(ph, 'round1') && !atOrAfter(ph, 'reveal') && (
        <p className="faint small center" style={{ marginTop: 24 }}>{MISSION_RULES}</p>
      )}
    </main>
  );
}

/* ---------------- pieces ---------------- */

function PlayerList({ players, right }: { players: PublicPlayer[]; right?: (p: PublicPlayer) => React.ReactNode }) {
  return (
    <ul className="plist">
      {players.map((p) => (
        <li key={p.id}>
          <div className="who">
            <b>{p.name}</b>
            <span>{p.costume || ' '}</span>
          </div>
          {right?.(p)}
        </li>
      ))}
    </ul>
  );
}

function Waiting({ text }: { text: string }) {
  return (
    <section className="card">
      <p className="muted">{text}</p>
    </section>
  );
}

function MissionBlock(props: {
  round: 1 | 2;
  mission: Mission | null;
  pair: number | null;
  done: boolean;
  guests: string;
  editable: boolean;
  closedNote: string | null;
  lockUndo?: boolean;
  act: Act;
  busy: boolean;
}) {
  const { round, mission, pair, done, guests, editable, closedNote, lockUndo, act, busy } = props;
  const [editing, setEditing] = useState(false);
  const [text, setText] = useState('');
  if (!mission) return null;

  return (
    <section className="card stack">
      <div className="spread">
        <div className="eyebrow">Round {round} mission</div>
        {pair && <span className="faint small">Pair {String(pair).padStart(2, '0')}</span>}
      </div>
      <HoldReveal label={`Hold to read mission ${round === 1 ? 'one' : 'two'}`}>
        <h3 className="gold">{mission.title}</h3>
        <p>{mission.text}</p>
        <p className="small faint">Success unlocks 1 bonus chip.</p>
      </HoldReveal>

      {done ? (
        <div className="spread">
          <div>
            <span className="badge neutral" style={{ color: 'var(--ok)' }}>Completed</span>
            {guests && <div className="muted small" style={{ marginTop: 6 }}>With: {guests}</div>}
          </div>
          {editable && !lockUndo && (
            <button className="mini ghost" disabled={busy} onClick={() => act('mission', { round, done: false })}>
              Undo
            </button>
          )}
        </div>
      ) : editable ? (
        editing ? (
          <div className="stack">
            <div>
              <label>Guests involved (for your own record)</label>
              <input value={text} onChange={(e) => setText(e.target.value)} placeholder="e.g. Nadia, Rafi" maxLength={200} />
            </div>
            <div className="row">
              <button
                disabled={busy}
                onClick={async () => {
                  if (await act('mission', { round, done: true, guests: text })) setEditing(false);
                }}
              >
                Confirm complete
              </button>
              <button className="ghost" onClick={() => setEditing(false)}>Cancel</button>
            </div>
            <p className="faint small">Only confirm if you completed the whole task.</p>
          </div>
        ) : (
          <button className="block ghost" onClick={() => setEditing(true)}>
            Mark mission complete
          </button>
        )
      ) : (
        <p className="muted small">{closedNote ?? ''}{closedNote && ' '}Not completed.</p>
      )}
    </section>
  );
}

function Chips({ view }: { view: PlayerView }) {
  const me = view.me;
  const spent = !!me.reading;
  return (
    <section className="card stack">
      <div className="eyebrow">Your chips</div>
      <div className="chips">
        <span className="chip on">3 ordinary votes</span>
        <span className={`chip ${me.firstEarned ? 'on' : ''} ${spent ? 'spent' : ''}`}>
          1st bonus {me.firstEarned ? (spent ? '(spent on reading)' : 'earned') : 'locked'}
        </span>
        <span className={`chip ${me.secondEarned ? 'on' : ''}`}>
          2nd bonus {me.secondEarned ? 'earned' : 'locked'}
        </span>
      </div>
      <p className="faint small">
        First bonus always counts unless spent on a soul reading. Second bonus counts only if your faction wins.
      </p>
    </section>
  );
}

function SealPanel(props: { round: 1 | 2; sealed: boolean; canSeal: boolean; count: number | null; act: Act; busy: boolean }) {
  const { round, sealed, canSeal, count, act, busy } = props;
  return (
    <section className="card stack glow">
      <div className="eyebrow">{round === 1 ? 'Midpoint toast' : 'Finale'}</div>
      {count !== null ? (
        <div className="center stack">
          <p className="muted">Curses so far</p>
          <div className="big-number">{count}</div>
          <p className="muted small">Mission two opens in a moment.</p>
        </div>
      ) : sealed ? (
        <p>Your slip is sealed in the crown bowl. Waiting for the others.</p>
      ) : (
        <>
          <p>
            Mission {round === 1 ? 'one' : 'two'} is closing. Check your mission status above, then seal your slip.
            Everyone taps the same button; the crown decides what your slip says.
          </p>
          <button className="block" disabled={!canSeal || busy} onClick={() => act('seal', { round })}>
            Seal my slip
          </button>
        </>
      )}
    </section>
  );
}

function ReadingPanel({ view, act, busy }: { view: PlayerView; act: Act; busy: boolean }) {
  const me = view.me;
  const [target, setTarget] = useState('');
  if (me.reading) return null;
  const options = view.players.filter((p) => p.inGame && p.id !== me.id);
  return (
    <section className="card stack">
      <div className="eyebrow">Soul reading</div>
      {!me.firstEarned ? (
        <p className="muted">
          A reading costs your first bonus chip. Complete a mission to earn one. Readings close when the finale begins.
        </p>
      ) : (
        <>
          <p className="muted small">
            Once per game. Spend your first bonus chip (one costume vote) to privately see one player&apos;s true
            allegiance. Only you will see it.
          </p>
          <select value={target} onChange={(e) => setTarget(e.target.value)}>
            <option value="">Choose a player…</option>
            {options.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
                {p.costume ? ` (${p.costume})` : ''}
              </option>
            ))}
          </select>
          <button
            className="block"
            disabled={!target || busy || !me.can.reading}
            onClick={() => {
              const n = options.find((p) => p.id === target)?.name;
              if (confirm(`Spend your first bonus chip to read ${n}'s soul? This can't be undone.`)) act('reading', { target });
            }}
          >
            Read their soul
          </button>
        </>
      )}
    </section>
  );
}

function PickPanel(props: {
  title: string;
  intro: string;
  options: PublicPlayer[];
  count: number;
  current: string[] | null;
  busy: boolean;
  onSubmit: (ids: string[]) => Promise<boolean>;
}) {
  const { title, intro, options, count, current, busy, onSubmit } = props;
  const [sel, setSel] = useState<string[]>(current ?? []);
  const [editing, setEditing] = useState(!current);

  if (current && !editing) {
    return (
      <section className="card stack">
        <div className="eyebrow">{title}</div>
        <p>Submitted: <b>{current.map((id) => options.find((o) => o.id === id)?.name ?? '?').join(', ')}</b></p>
        <p className="muted small">You can change this until the host tallies.</p>
        <button
          className="ghost"
          onClick={() => {
            setSel(current);
            setEditing(true);
          }}
        >
          Change
        </button>
      </section>
    );
  }

  const toggle = (id: string) =>
    setSel((s) => (s.includes(id) ? s.filter((x) => x !== id) : count === 1 ? [id] : s.length < count ? [...s, id] : s));

  return (
    <section className="card stack glow">
      <div className="eyebrow">{title}</div>
      <p className="muted small">{intro}</p>
      <div className="stack" style={{ gap: 8 }}>
        {options.map((p) => {
          const on = sel.includes(p.id);
          return (
            <button key={p.id} className={`pick block ${on ? 'on' : ''}`} onClick={() => toggle(p.id)}>
              <span style={{ textAlign: 'left' }}>
                <b>{p.name}</b>
                {p.costume && <span className="muted small"> · {p.costume}</span>}
              </span>
              <span className="tick">{on ? '✓' : ''}</span>
            </button>
          );
        })}
      </div>
      <button
        className="block"
        disabled={sel.length !== count || busy}
        onClick={async () => {
          if (await onSubmit(sel)) setEditing(false);
        }}
      >
        Submit {sel.length}/{count}
      </button>
    </section>
  );
}

function RevealPanel({ view }: { view: PlayerView }) {
  const me = view.me;
  const total = (view.midpointCurses ?? 0) + (view.finaleCurses ?? 0);
  const rows = view.reveal ?? [];
  const roleOf = (id: string) => rows.find((r) => r.id === id)?.role;
  const caught = (view.suspects ?? []).filter((id) => roleOf(id) === 'hunter').length;
  const name = (id: string) => view.players.find((p) => p.id === id);
  const hunters = rows.filter((r) => r.role === 'hunter');
  const won = me.role && view.winner ? (me.role === 'hunter') === (view.winner === 'hunters') : null;

  return (
    <>
      <section className={`card banner ${view.winner}`}>
        <div className="eyebrow">The crown belongs to</div>
        <h1 className={view.winner === 'hunters' ? 'blood' : 'violet'}>
          {view.winner === 'hunters' ? 'The Hunters' : 'The Monsters'}
        </h1>
        {won !== null && <p className="muted">{won ? 'Your side won.' : 'Your side lost.'}</p>}
      </section>

      <section className="card stack">
        <div className="spread">
          <span>Curses</span>
          <b>
            {view.midpointCurses ?? 0} + {view.finaleCurses ?? 0} = {total}
            <span className="muted"> / {view.threshold} needed</span>
          </b>
        </div>
        <div className="spread">
          <span>Hunters among suspects</span>
          <b>
            {caught} <span className="muted">/ 2 to stop them</span>
          </b>
        </div>
      </section>

      <section className="card stack">
        <div className="eyebrow">The suspects</div>
        <PlayerList
          players={(view.suspects ?? []).map((id) => name(id)!).filter(Boolean)}
          right={(p) => <RoleBadge role={roleOf(p.id)} />}
        />
      </section>

      <section className="card stack">
        <div className="eyebrow">The Hunters</div>
        <PlayerList
          players={hunters.map((r) => name(r.id)!).filter(Boolean)}
          right={(p) => {
            const m = rows.find((r) => r.id === p.id)?.missions ?? 0;
            return <span className="badge hunter">{m} curse{m === 1 ? '' : 's'}</span>;
          }}
        />
      </section>

      {me.voteAllowance !== null && (
        <section className="card stack">
          <div className="eyebrow">Your costume votes</div>
          <div className="big-number" style={{ fontSize: '3rem' }}>{me.voteAllowance}</div>
          <p className="muted small">
            3 ordinary
            {me.role && me.firstEarned && !me.reading ? ' + 1st bonus' : ''}
            {me.role && me.secondEarned && won ? ' + 2nd bonus (faction won)' : ''}
            {me.role && me.secondEarned && !won ? '. 2nd bonus void, your faction lost' : ''}
            {me.reading ? '. 1st bonus spent on a reading' : ''}.
          </p>
        </section>
      )}
    </>
  );
}

function RoleBadge({ role }: { role?: 'hunter' | 'monster' }) {
  if (!role) return null;
  return <span className={`badge ${role}`}>{role}</span>;
}

function VotePanel({ view, act, busy }: { view: PlayerView; act: Act; busy: boolean }) {
  const me = view.me;
  const allowance = me.voteAllowance ?? 3;
  const [alloc, setAlloc] = useState<Record<string, number>>(me.costumeVotes ?? {});
  const [editing, setEditing] = useState(!me.costumeVotes);
  const used = Object.values(alloc).reduce((a, b) => a + b, 0);
  const others = view.players.filter((p) => p.id !== me.id);

  if (me.costumeVotes && !editing) {
    return (
      <section className="card stack">
        <div className="eyebrow">Votes cast</div>
        <PlayerList
          players={others.filter((p) => me.costumeVotes![p.id])}
          right={(p) => <b className="gold">{me.costumeVotes![p.id]}</b>}
        />
        <p className="muted small">You can change these until the host crowns the winner.</p>
        <button className="ghost" onClick={() => { setAlloc(me.costumeVotes ?? {}); setEditing(true); }}>
          Change votes
        </button>
      </section>
    );
  }

  const set = (id: string, d: number) =>
    setAlloc((a) => {
      const cur = a[id] ?? 0;
      const next = Math.max(0, Math.min(3, cur + d));
      if (d > 0 && used >= allowance) return a;
      return { ...a, [id]: next };
    });

  return (
    <section className="card stack glow">
      <div className="spread">
        <div className="eyebrow">Crown the best costume</div>
        <b className="gold">{allowance - used} left</b>
      </div>
      <div className="progress"><i style={{ width: `${(used / allowance) * 100}%` }} /></div>
      <p className="muted small">No self-voting. Up to 3 votes per costume.</p>
      <PlayerList
        players={others}
        right={(p) => (
          <div className="stepper">
            <button className="ghost" onClick={() => set(p.id, -1)} disabled={!alloc[p.id]} aria-label={`Remove vote from ${p.name}`}>−</button>
            <b>{alloc[p.id] ?? 0}</b>
            <button onClick={() => set(p.id, 1)} disabled={used >= allowance || (alloc[p.id] ?? 0) >= 3} aria-label={`Add vote for ${p.name}`}>+</button>
          </div>
        )}
      />
      <button
        className="block"
        disabled={used === 0 || busy}
        onClick={async () => {
          if (await act('vote', { votes: alloc })) setEditing(false);
        }}
      >
        Cast {used} vote{used === 1 ? '' : 's'}
      </button>
    </section>
  );
}

function Results({ view }: { view: PlayerView }) {
  const c = view.players.find((p) => p.id === view.crowned);
  const tally = view.costumeTally ?? {};
  const ranked = [...view.players].filter((p) => tally[p.id]).sort((a, b) => (tally[b.id] ?? 0) - (tally[a.id] ?? 0));
  return (
    <>
      <section className="card banner glow">
        <div className="crown" style={{ fontSize: '3rem' }}>👑</div>
        <div className="eyebrow">Crowned tonight</div>
        <h1 className="gold">{c?.name}</h1>
        {c?.costume && <p className="muted">{c.costume}</p>}
      </section>
      {view.notes.length > 0 && <div className="notice small">{view.notes.join(' ')}</div>}
      <section className="card stack">
        <div className="eyebrow">Final tally</div>
        <PlayerList players={ranked} right={(p) => <b className="gold">{tally[p.id]}</b>} />
      </section>
    </>
  );
}
