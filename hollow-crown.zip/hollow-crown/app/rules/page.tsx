import Link from 'next/link';

export const metadata = { title: 'How to play · The Hollow Crown' };

export default function Rules() {
  return (
    <main className="wrap stack">
      <div className="topbar">
        <Link href="/" className="brand">THE HOLLOW CROWN</Link>
        <span className="pill">v2 rules</span>
      </div>
      <h1>How to play</h1>
      <p className="muted">
        Monsters have gathered to crown the best costume. Hidden Hunters are trying to curse the coronation. Nobody is
        eliminated, and everyone votes for the best costume at the end.
      </p>

      <section className="card stack">
        <div className="eyebrow">The teams</div>
        <p>
          About one in five players is secretly a <b className="blood">Hunter</b> (4 in a 20-player game). Everyone else
          is a <b className="violet">Monster</b>. Missions are identical in style for both sides, so odd behaviour alone
          is not evidence.
        </p>
      </section>

      <ol className="steps">
        <li>
          <h3>Join and read your secrets</h3>
          <p className="muted">
            Scan the host&apos;s QR code, enter your name and costume. Once the host deals, hold your cards to see your
            allegiance and mission one. Keep your screen to yourself.
          </p>
        </li>
        <li>
          <h3>Round 1: mingle and complete mission one</h3>
          <p className="muted">
            Missions happen in normal conversation. When you finish, tap Mark complete and note the guests involved.
            Completion is on honour. Each completed mission earns a bonus chip.
          </p>
        </li>
        <li>
          <h3>The midpoint toast</h3>
          <p className="muted">
            Mission one closes. Everyone taps the same Seal my slip button. The app quietly turns each completed Hunter
            mission into a curse, then the host reads out the curse count. Any drink counts; drinking is never required.
          </p>
        </li>
        <li>
          <h3>Round 2 and soul readings</h3>
          <p className="muted">
            Mission two opens. Once per player, you may spend your first earned bonus chip on a soul reading: pick a
            player and the app privately shows you their true allegiance. You may tell the truth or lie about it.
            Spending a chip costs you that costume vote.
          </p>
        </li>
        <li>
          <h3>The finale</h3>
          <p className="muted">
            Mission two and readings close. Seal your second slip. Three minutes of discussion (nobody has to speak),
            then everyone secretly nominates three other players. The three most nominated become the suspects. Ties at
            the cutoff get one runoff, then lots.
          </p>
        </li>
        <li>
          <h3>Who controls the crown?</h3>
          <p className="muted">
            Hunters win only if BOTH are true: curses across both checkpoints reach the target (4 in a 20-player game),
            AND fewer than two Hunters are among the three suspects. Otherwise Monsters win. Catching two Hunters
            defeats them outright.
          </p>
        </li>
        <li>
          <h3>Crown the best costume</h3>
          <p className="muted">
            Everyone gets 3 ordinary votes. Your first earned bonus counts unless you spent it on a reading. Your second
            earned bonus counts only if your faction won. No self-voting, at most 3 votes per costume. The app does the
            maths.
          </p>
        </li>
      </ol>

      <section className="card stack">
        <div className="eyebrow">House rules</div>
        <p className="small muted">
          Don&apos;t show your screen or read out a mission. You may ask directly or bluff about your motive, but don&apos;t
          offer votes for cooperation. If someone declines a mission request, ask someone else. Don&apos;t stop the music
          for a mission. Late arrivals can join the costume contest but not the hidden-role game.
        </p>
      </section>

      <div className="footer-links">
        <Link href="/">Back to start</Link>
      </div>
    </main>
  );
}
