'use client';
import { useEffect, useState } from 'react';
import { fmtClock } from '@/lib/copy';

function useNow() {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(id);
  }, []);
  return now;
}

/** offset = serverNow - clientTimeAtFetch */
export function Countdown({ endsAt, offset }: { endsAt: number; offset: number }) {
  const now = useNow();
  const left = endsAt - (now + offset);
  return <span className={`clock ${left <= 0 ? 'done' : ''}`}>{left <= 0 ? "Time's up" : fmtClock(left)}</span>;
}

export function Elapsed({ since, offset }: { since: number; offset: number }) {
  const now = useNow();
  return <span className="clock">{fmtClock(now + offset - since)}</span>;
}
