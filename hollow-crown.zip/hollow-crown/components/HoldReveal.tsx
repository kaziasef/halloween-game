'use client';
import { useState, type ReactNode } from 'react';

export default function HoldReveal({ label, children }: { label: string; children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const hide = () => setOpen(false);
  return (
    <div
      className={`hold ${open ? 'open' : ''}`}
      role="button"
      tabIndex={0}
      aria-label={label}
      onPointerDown={(e) => {
        e.preventDefault();
        setOpen(true);
      }}
      onPointerUp={hide}
      onPointerLeave={hide}
      onPointerCancel={hide}
      onContextMenu={(e) => e.preventDefault()}
      onKeyDown={(e) => {
        if (e.key === ' ' || e.key === 'Enter') {
          e.preventDefault();
          setOpen(true);
        }
      }}
      onKeyUp={hide}
      onBlur={hide}
    >
      {open ? (
        <div className="hold-content">{children}</div>
      ) : (
        <div className="hold-cover">
          <span className="sigil" aria-hidden>
            ☾
          </span>
          <span>{label}</span>
        </div>
      )}
    </div>
  );
}
