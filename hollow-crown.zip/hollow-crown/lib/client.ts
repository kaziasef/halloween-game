'use client';
import { useCallback, useEffect, useRef, useState } from 'react';

export async function post(url: string, body: unknown): Promise<{ ok: boolean; error?: string }> {
  try {
    const r = await fetch(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) return { ok: false, error: j.error || `Something went wrong (${r.status}).` };
    return { ok: true, ...j };
  } catch {
    return { ok: false, error: 'Network hiccup. Try again.' };
  }
}

export function usePoll<T>(url: string | null, headers: Record<string, string>, ms = 3000) {
  const [data, setData] = useState<T | null>(null);
  const [status, setStatus] = useState<number | null>(null);
  const [offline, setOffline] = useState(false);
  const h = JSON.stringify(headers);
  const inflight = useRef(false);

  const refresh = useCallback(async () => {
    if (!url || inflight.current) return;
    inflight.current = true;
    try {
      const r = await fetch(url, { cache: 'no-store', headers: JSON.parse(h) });
      setStatus(r.status);
      if (r.ok) {
        const j = await r.json();
        setData({ ...j, _clientAt: Date.now() });
      }
      setOffline(false);
    } catch {
      setOffline(true);
    } finally {
      inflight.current = false;
    }
  }, [url, h]);

  useEffect(() => {
    if (!url) return;
    refresh();
    const id = setInterval(() => {
      if (!document.hidden) refresh();
    }, ms);
    const onVis = () => {
      if (!document.hidden) refresh();
    };
    document.addEventListener('visibilitychange', onVis);
    return () => {
      clearInterval(id);
      document.removeEventListener('visibilitychange', onVis);
    };
  }, [url, ms, refresh]);

  return { data, status, offline, refresh };
}

export function store(key: string, value?: string | null): string | null {
  try {
    if (value === undefined) return localStorage.getItem(key);
    if (value === null) localStorage.removeItem(key);
    else localStorage.setItem(key, value);
  } catch {}
  return null;
}
