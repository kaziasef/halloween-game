import type { Phase } from './types';

export const PHASE_LABEL: Record<Phase, string> = {
  lobby: 'Gathering',
  round1: 'Round 1',
  midpoint: 'Midpoint toast',
  round2: 'Round 2',
  finale: 'Finale',
  nominate: 'Nominations',
  runoff: 'Suspect runoff',
  suspects: 'The suspects',
  reveal: 'The reveal',
  vote: 'Costume vote',
  costumeRunoff: 'Costume runoff',
  results: 'Coronation',
};

export const ORDER: Phase[] = [
  'lobby', 'round1', 'midpoint', 'round2', 'finale', 'nominate', 'runoff',
  'suspects', 'reveal', 'vote', 'costumeRunoff', 'results',
];
export const atOrAfter = (p: Phase, q: Phase) => ORDER.indexOf(p) >= ORDER.indexOf(q);

export function roleText(role: 'monster' | 'hunter', threshold: number) {
  return role === 'monster'
    ? {
        title: 'Monster',
        body: `Your completed missions never curse the crown. Monsters win if there are fewer than ${threshold} curse${threshold === 1 ? '' : 's'} OR at least 2 Hunters among the 3 suspects. Find the Hunters.`,
      }
    : {
        title: 'Hunter',
        body: `Every mission you complete curses the crown. Hunters win with ${threshold}+ curse${threshold === 1 ? '' : 's'} AND fewer than 2 Hunters among the 3 suspects. Stay hidden.`,
      };
}

export const fmtClock = (ms: number) => {
  const s = Math.max(0, Math.floor(ms / 1000));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
};
