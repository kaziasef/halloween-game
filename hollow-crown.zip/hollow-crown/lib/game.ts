import { PAIRS } from './missions';
import type { Faction, HostView, Meta, Phase, Player, PlayerView, PublicState, Role } from './types';

export const MIN_PLAYERS = 5;
export const RECOMMENDED_MIN = 10;
export const MAX_PLAYERS = 30;
export const SUSPECTS = 3;
export const NOMINATIONS = 3;
export const MAX_PER_COSTUME = 3;
export const DISCUSSION_MS = 3 * 60 * 1000;

/** 1 Hunter per ~5 players (4 at 20), min 2 once the game has 10+ players. */
export function hunterCount(n: number): number {
  return n >= RECOMMENDED_MIN ? Math.max(2, Math.round(n / 5)) : 1;
}

export function randInt(n: number): number {
  const a = new Uint32Array(1);
  crypto.getRandomValues(a);
  return a[0] % n;
}

export function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = randInt(i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function makeCode(): string {
  const A = 'BCDFGHJKLMNPQRSTVWXZ';
  let s = '';
  for (let i = 0; i < 4; i++) s += A[randInt(A.length)];
  return s;
}

export const faction = (r: Role): Faction => (r === 'hunter' ? 'hunters' : 'monsters');
export const firstEarned = (p: Player) => p.m1Done || p.m2Done;
export const secondEarned = (p: Player) => p.m1Done && p.m2Done;

/** 3 ordinary + first bonus (unless spent on a reading) + second bonus only if your faction won. */
export function voteAllowance(p: Player, winner: Faction | null): number {
  if (!p.role) return 3;
  let v = 3;
  if (firstEarned(p) && !p.reading) v += 1;
  if (secondEarned(p) && winner && faction(p.role) === winner) v += 1;
  return v;
}

export function newMeta(code: string, hostToken: string): Meta {
  const now = Date.now();
  return {
    code,
    hostToken,
    createdAt: now,
    phase: 'lobby',
    phaseStartedAt: now,
    hunters: 0,
    threshold: 0,
    midpointCurses: null,
    finaleCurses: null,
    discussionEndsAt: null,
    suspects: null,
    runoff: null,
    winner: null,
    costumeTally: null,
    costumeRunoff: null,
    crowned: null,
    notes: [],
  };
}

export function newPlayer(name: string, costume: string): Player {
  return {
    id: crypto.randomUUID().slice(0, 8),
    token: crypto.randomUUID(),
    name,
    costume,
    joinedAt: Date.now(),
    role: null,
    pair: null,
    m1Done: false,
    m1Guests: '',
    m2Done: false,
    m2Guests: '',
    sealed1: false,
    sealed2: false,
    reading: null,
    nominations: null,
    runoffPicks: null,
    costumeVotes: null,
    costumeRunoffPick: null,
  };
}

/** Roles and mission pairs are shuffled independently. Pairs repeat only past 20 players. */
export function deal(players: Player[]): { players: Player[]; hunters: number } {
  const sorted = [...players].sort((a, b) => a.joinedAt - b.joinedAt);
  const n = sorted.length;
  const h = hunterCount(n);
  const roles = shuffle<Role>(Array.from({ length: n }, (_, i) => (i < h ? 'hunter' : 'monster')));
  let pairs: number[] = [];
  while (pairs.length < n) pairs = pairs.concat(shuffle(PAIRS.map((_, i) => i + 1)));
  pairs = shuffle(pairs.slice(0, n));
  return { players: sorted.map((p, i) => ({ ...p, role: roles[i], pair: pairs[i] })), hunters: h };
}

export function tally(lists: (string[] | null | undefined)[]): Record<string, number> {
  const c: Record<string, number> = {};
  for (const l of lists) for (const id of l ?? []) c[id] = (c[id] ?? 0) + 1;
  return c;
}

/** Fill clear places first; report a tie at the cutoff instead of guessing. */
export function pickTop(candidates: string[], counts: Record<string, number>, slots: number) {
  const sorted = [...candidates].sort((a, b) => (counts[b] ?? 0) - (counts[a] ?? 0));
  if (sorted.length <= slots) return { chosen: sorted, tied: [] as string[], open: 0 };
  const cut = counts[sorted[slots - 1]] ?? 0;
  const clear = sorted.filter((id) => (counts[id] ?? 0) > cut);
  const tied = sorted.filter((id) => (counts[id] ?? 0) === cut);
  const open = slots - clear.length;
  if (tied.length === open) return { chosen: [...clear, ...tied], tied: [] as string[], open: 0 };
  return { chosen: clear, tied, open };
}

export function drawLots(ids: string[], k: number): string[] {
  return shuffle(ids).slice(0, k);
}

/* ---------- permissions ---------- */

export function can(meta: Meta, p: Player) {
  const r = !!p.role;
  const ph = meta.phase;
  return {
    m1: r && (ph === 'round1' || (ph === 'midpoint' && !p.sealed1 && meta.midpointCurses === null)),
    m2: r && (ph === 'round2' || (ph === 'finale' && !p.sealed2)),
    seal1: r && ph === 'midpoint' && !p.sealed1 && meta.midpointCurses === null,
    seal2: r && ph === 'finale' && !p.sealed2,
    reading: r && ph === 'round2' && !p.reading && firstEarned(p),
  };
}

/* ---------- views ---------- */

const REVEAL_PHASES: Phase[] = ['reveal', 'vote', 'costumeRunoff', 'results'];

function publicState(meta: Meta, players: Player[]): PublicState {
  const sorted = [...players].sort((a, b) => a.joinedAt - b.joinedAt);
  const revealed = REVEAL_PHASES.includes(meta.phase);
  return {
    code: meta.code,
    phase: meta.phase,
    phaseStartedAt: meta.phaseStartedAt,
    serverNow: Date.now(),
    players: sorted.map((p) => ({ id: p.id, name: p.name, costume: p.costume, inGame: !!p.role })),
    inGameCount: sorted.filter((p) => p.role).length,
    hunters: meta.hunters,
    threshold: meta.threshold,
    midpointCurses: meta.midpointCurses,
    finaleCurses: revealed ? meta.finaleCurses : null,
    discussionEndsAt: meta.discussionEndsAt,
    suspects: meta.suspects,
    runoff: meta.runoff,
    winner: revealed ? meta.winner : null,
    costumeTally: meta.phase === 'results' ? meta.costumeTally : null,
    costumeRunoff: meta.costumeRunoff,
    crowned: meta.crowned,
    notes: meta.notes,
    reveal: revealed
      ? sorted
          .filter((p) => p.role)
          .map((p) => ({ id: p.id, role: p.role as Role, missions: (p.m1Done ? 1 : 0) + (p.m2Done ? 1 : 0) }))
      : null,
  };
}

export function playerView(meta: Meta, players: Player[], me: Player): PlayerView {
  const pair = me.pair ? PAIRS[me.pair - 1] : null;
  const showR2 = ['round2', 'finale', 'nominate', 'runoff', 'suspects', ...REVEAL_PHASES].includes(meta.phase);
  const target = me.reading ? players.find((p) => p.id === me.reading!.target) : null;
  return {
    ...publicState(meta, players),
    me: {
      id: me.id,
      name: me.name,
      costume: me.costume,
      role: me.role,
      pair: me.pair,
      r1: pair ? pair.r1 : null,
      r2: pair && showR2 ? pair.r2 : null,
      m1Done: me.m1Done,
      m1Guests: me.m1Guests,
      m2Done: me.m2Done,
      m2Guests: me.m2Guests,
      sealed1: me.sealed1,
      sealed2: me.sealed2,
      reading: me.reading
        ? { targetId: me.reading.target, targetName: target?.name ?? 'Unknown', role: me.reading.role }
        : null,
      firstEarned: firstEarned(me),
      secondEarned: secondEarned(me),
      voteAllowance: REVEAL_PHASES.includes(meta.phase) ? voteAllowance(me, meta.winner) : null,
      nominations: me.nominations,
      runoffPicks: me.runoffPicks,
      costumeVotes: me.costumeVotes,
      costumeRunoffPick: me.costumeRunoffPick,
      can: can(meta, me),
    },
  };
}

export function hostView(meta: Meta, players: Player[], storage: 'redis' | 'memory'): HostView {
  const inGame = players.filter((p) => p.role);
  return {
    ...publicState(meta, players),
    storage,
    counts: {
      sealed1: inGame.filter((p) => p.sealed1).length,
      sealed2: inGame.filter((p) => p.sealed2).length,
      nominated: inGame.filter((p) => p.nominations).length,
      runoffPicked: inGame.filter((p) => p.runoffPicks).length,
      voted: players.filter((p) => p.costumeVotes).length,
      costumeRunoffPicked: players.filter((p) => p.costumeRunoffPick).length,
    },
  };
}

/* ---------- player actions ---------- */

type Body = Record<string, unknown>;
const str = (v: unknown) => (typeof v === 'string' ? v : '');
const strArr = (v: unknown) => (Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string') : []);

/** Mutates `me`. Returns an error message, or null on success. */
export function applyPlayerAction(meta: Meta, players: Player[], me: Player, body: Body): string | null {
  const c = can(meta, me);
  const inGameOthers = players.filter((p) => p.role && p.id !== me.id).map((p) => p.id);

  switch (body.type) {
    case 'mission': {
      const round = body.round === 2 ? 2 : 1;
      const done = !!body.done;
      const guests = str(body.guests).trim().slice(0, 200);
      if (round === 1) {
        if (!c.m1) return 'Mission one is closed.';
        me.m1Done = done;
        me.m1Guests = done ? guests : '';
      } else {
        if (!c.m2) return 'Mission two is not open right now.';
        if (!done && me.reading && !me.m1Done)
          return 'This mission paid for your soul reading, so it can no longer be undone.';
        me.m2Done = done;
        me.m2Guests = done ? guests : '';
      }
      return null;
    }
    case 'seal': {
      if (body.round === 2) {
        if (!c.seal2) return 'You cannot seal a slip right now.';
        me.sealed2 = true;
      } else {
        if (!c.seal1) return 'You cannot seal a slip right now.';
        me.sealed1 = true;
      }
      return null;
    }
    case 'reading': {
      if (!c.reading) {
        if (me.reading) return 'You have already used your soul reading.';
        if (!firstEarned(me)) return 'You need an earned bonus chip to pay for a reading.';
        return 'Soul readings are closed.';
      }
      const t = players.find((p) => p.id === str(body.target));
      if (!t || !t.role || t.id === me.id) return 'Pick another player who is in the game.';
      me.reading = { target: t.id, role: t.role };
      return null;
    }
    case 'nominate': {
      if (meta.phase !== 'nominate' || !me.role) return 'Nominations are closed.';
      const ids = [...new Set(strArr(body.ids))];
      const need = Math.min(NOMINATIONS, inGameOthers.length);
      if (ids.length !== need || !ids.every((id) => inGameOthers.includes(id)))
        return `Pick exactly ${need} different other players.`;
      me.nominations = ids;
      return null;
    }
    case 'runoff': {
      if (meta.phase !== 'runoff' || !me.role || !meta.runoff) return 'The runoff is closed.';
      const options = meta.runoff.candidates.filter((id) => id !== me.id);
      const need = Math.min(meta.runoff.slots, options.length);
      const ids = [...new Set(strArr(body.ids))];
      if (ids.length !== need || !ids.every((id) => options.includes(id)))
        return `Pick exactly ${need} of the tied players.`;
      me.runoffPicks = ids;
      return null;
    }
    case 'vote': {
      if (meta.phase !== 'vote') return 'Costume voting is not open.';
      const raw = (body.votes ?? {}) as Record<string, unknown>;
      const allowance = voteAllowance(me, meta.winner);
      const clean: Record<string, number> = {};
      let total = 0;
      for (const [id, v] of Object.entries(raw)) {
        const n = Math.floor(Number(v));
        if (!n) continue;
        if (id === me.id) return 'No voting for your own costume.';
        if (!players.some((p) => p.id === id)) return 'Unknown costume.';
        if (n < 0 || n > MAX_PER_COSTUME) return `Maximum ${MAX_PER_COSTUME} votes per costume.`;
        clean[id] = n;
        total += n;
      }
      if (total === 0) return 'Place at least one vote.';
      if (total > allowance) return `You only have ${allowance} votes.`;
      me.costumeVotes = clean;
      return null;
    }
    case 'costumeRunoff': {
      if (meta.phase !== 'costumeRunoff' || !meta.costumeRunoff) return 'The costume runoff is closed.';
      const id = str(body.id);
      if (id === me.id || !meta.costumeRunoff.includes(id)) return 'Pick one of the other tied costumes.';
      me.costumeRunoffPick = id;
      return null;
    }
  }
  return 'Unknown action.';
}

/* ---------- host actions ---------- */

/** Mutates meta (and returns players to save). Returns error or null. */
export function applyHostAction(
  meta: Meta,
  players: Player[],
  body: Body,
): { error: string | null; save: Player[]; remove?: string } {
  const now = Date.now();
  const go = (phase: Phase) => {
    meta.phase = phase;
    meta.phaseStartedAt = now;
  };
  const inGame = players.filter((p) => p.role);
  const name = (id: string) => players.find((p) => p.id === id)?.name ?? '?';
  const ok = (save: Player[] = []) => ({ error: null, save });
  const fail = (error: string) => ({ error, save: [] as Player[] });

  switch (body.type) {
    case 'kick': {
      const p = players.find((x) => x.id === str(body.id));
      if (!p) return fail('Player not found.');
      if (p.role) return fail('Players with a dealt role cannot be removed.');
      return { error: null, save: [], remove: p.id };
    }
    case 'deal': {
      if (meta.phase !== 'lobby') return fail('Already dealt.');
      if (players.length < MIN_PLAYERS) return fail(`Need at least ${MIN_PLAYERS} players.`);
      if (players.length > MAX_PLAYERS) return fail(`Maximum ${MAX_PLAYERS} players.`);
      const d = deal(players);
      meta.hunters = d.hunters;
      meta.threshold = d.hunters;
      go('round1');
      return ok(d.players);
    }
    case 'midpoint':
      if (meta.phase !== 'round1') return fail('Not in Round 1.');
      go('midpoint');
      return ok();
    case 'count':
      if (meta.phase !== 'midpoint' || meta.midpointCurses !== null) return fail('Curses already counted.');
      meta.midpointCurses = inGame.filter((p) => p.role === 'hunter' && p.m1Done).length;
      return ok();
    case 'round2':
      if (meta.phase !== 'midpoint') return fail('Not at the midpoint.');
      if (meta.midpointCurses === null) return fail('Count the curses first.');
      go('round2');
      return ok();
    case 'finale':
      if (meta.phase !== 'round2') return fail('Not in Round 2.');
      go('finale');
      return ok();
    case 'discussion':
      if (meta.phase !== 'finale' && meta.phase !== 'nominate') return fail('Discussion happens at the finale.');
      meta.discussionEndsAt = now + DISCUSSION_MS;
      return ok();
    case 'nominate':
      if (meta.phase !== 'finale') return fail('Not at the finale.');
      go('nominate');
      return ok();
    case 'tally': {
      if (meta.phase !== 'nominate') return fail('Nominations are not open.');
      const counts = tally(inGame.map((p) => p.nominations));
      const r = pickTop(
        inGame.map((p) => p.id),
        counts,
        SUSPECTS,
      );
      if (r.tied.length) {
        meta.runoff = { candidates: r.tied, slots: r.open, chosen: r.chosen };
        go('runoff');
      } else {
        meta.suspects = r.chosen;
        go('suspects');
      }
      return ok();
    }
    case 'tallyRunoff': {
      if (meta.phase !== 'runoff' || !meta.runoff) return fail('No runoff in progress.');
      const { candidates, slots, chosen } = meta.runoff;
      const r = pickTop(candidates, tally(inGame.map((p) => p.runoffPicks)), slots);
      let final = [...chosen, ...r.chosen];
      if (r.tied.length) {
        const lots = drawLots(r.tied, r.open);
        meta.notes.push(`Still tied after the runoff, so lots were drawn: ${lots.map(name).join(', ')}.`);
        final = final.concat(lots);
      }
      meta.suspects = final;
      go('suspects');
      return ok();
    }
    case 'reveal': {
      if (meta.phase !== 'suspects' || !meta.suspects) return fail('Pick the suspects first.');
      meta.finaleCurses = inGame.filter((p) => p.role === 'hunter' && p.m2Done).length;
      const total = (meta.midpointCurses ?? 0) + meta.finaleCurses;
      const caught = meta.suspects.filter((id) => players.find((p) => p.id === id)?.role === 'hunter').length;
      meta.winner = total >= meta.threshold && caught < 2 ? 'hunters' : 'monsters';
      go('reveal');
      return ok();
    }
    case 'vote':
      if (meta.phase !== 'reveal') return fail('Reveal first.');
      go('vote');
      return ok();
    case 'crown': {
      if (meta.phase !== 'vote') return fail('Voting is not open.');
      const counts: Record<string, number> = {};
      for (const p of players) for (const [id, n] of Object.entries(p.costumeVotes ?? {})) counts[id] = (counts[id] ?? 0) + n;
      meta.costumeTally = counts;
      const max = Math.max(0, ...players.map((p) => counts[p.id] ?? 0));
      const top = players.filter((p) => (counts[p.id] ?? 0) === max).map((p) => p.id);
      if (top.length === 1) {
        meta.crowned = top[0];
        go('results');
      } else {
        meta.costumeRunoff = top;
        go('costumeRunoff');
      }
      return ok();
    }
    case 'crownRunoff': {
      if (meta.phase !== 'costumeRunoff' || !meta.costumeRunoff) return fail('No costume runoff.');
      const tied = meta.costumeRunoff;
      const counts = tally(players.map((p) => (p.costumeRunoffPick ? [p.costumeRunoffPick] : null)));
      const max = Math.max(0, ...tied.map((id) => counts[id] ?? 0));
      const top = tied.filter((id) => (counts[id] ?? 0) === max);
      if (top.length > 1) {
        meta.crowned = drawLots(top, 1)[0];
        meta.notes.push(`Costume runoff tied, so lots were drawn between ${top.map(name).join(', ')}.`);
      } else meta.crowned = top[0];
      go('results');
      return ok();
    }
  }
  return fail('Unknown action.');
}
