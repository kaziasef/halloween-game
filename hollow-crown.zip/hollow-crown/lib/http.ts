import { NextResponse } from 'next/server';

export const json = (data: unknown, status = 200) =>
  NextResponse.json(data, { status, headers: { 'cache-control': 'no-store' } });
export const err = (message: string, status = 400) => json({ error: message }, status);

export async function readBody(req: Request): Promise<Record<string, unknown>> {
  try {
    const b = await req.json();
    return b && typeof b === 'object' ? (b as Record<string, unknown>) : {};
  } catch {
    return {};
  }
}

export const cleanCode = (c: string) => c.toUpperCase().replace(/[^A-Z]/g, '').slice(0, 4);
