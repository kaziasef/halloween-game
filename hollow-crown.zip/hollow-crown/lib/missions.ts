export interface Mission {
  title: string;
  text: string;
}

export interface MissionPair {
  r1: Mission;
  r2: Mission;
}

// Pair N is PAIRS[N - 1]. Text matches the printed v2 cards.
export const PAIRS: MissionPair[] = [
  {
    r1: { title: 'A new name', text: 'Get one guest to invent a nickname for your costume. Then get a different guest to address you by that nickname.' },
    r2: { title: 'Hidden talents', text: 'Ask a guest which character here would win a haunted talent show, and why. Get a second guest to agree or nominate a different character with a reason.' },
  },
  {
    r1: { title: 'Signature move', text: 'Ask a guest to invent a signature gesture for your character. Get a different guest to perform it with you. No touching is needed.' },
    r2: { title: 'Relic collectors', text: 'Get two different guests to give one visible detail of their own costume an extravagant magical name. Each must say their invented name aloud.' },
  },
  {
    r1: { title: 'The legend grows', text: 'Start a fictional story about how this party came to be. Get two different guests to each add a sentence, one after the other.' },
    r2: { title: 'An honorary title', text: 'Get a guest to award a different guest a grand supernatural title. The recipient must accept it aloud with a short acceptance line.' },
  },
  {
    r1: { title: 'Hotel management', text: 'Ask two guests, separately, which character at the party should manage a haunted hotel. Each must choose someone and explain their choice.' },
    r2: { title: 'The party anthem', text: 'Get two guests to suggest a theme song for this gathering of monsters. Have them agree on one. You do not need to play it or change the music.' },
  },
  {
    r1: { title: 'A phrase catches on', text: 'Introduce the phrase "royally suspicious" in conversation. Get a guest to use those exact words while speaking to a different guest.' },
    r2: { title: 'Old rivals', text: 'Get two guests to imagine their characters are ancient rivals. Have each invent a ridiculous petty grudge against the other.' },
  },
  {
    r1: { title: 'The interviewer', text: 'Persuade one guest to ask another about the inspiration for their costume. Stay to hear both the question and the answer.' },
    r2: { title: 'The portrait director', text: 'Get someone else to assemble and direct a dramatic group pose with at least three guests, including you. Hold it for five seconds. A photo is optional.' },
  },
  {
    r1: { title: 'A royal introduction', text: 'Get one guest to introduce you to another using an invented royal title. Keep it within your conversation; no room-wide announcement.' },
    r2: { title: 'The sidekick debate', text: 'Get two guests to suggest different fictional sidekicks for your character. Have them discuss the choices and agree on one.' },
  },
  {
    r1: { title: 'Open for business', text: 'Invent a silly fictional service your character offers. Get one guest to recommend it to a second guest, who must pretend to book an appointment.' },
    r2: { title: 'Living statues', text: 'Persuade two other guests to join you in a three-person statue pose. Everyone must hold still for five seconds. No touching is needed.' },
  },
  {
    r1: { title: 'Secret weaknesses', text: 'Ask two guests, separately, for one ridiculous weakness their costumed character might have. Get an invented answer from each.' },
    r2: { title: 'A dedicated toast', text: "Get a guest to lead a toast praising a specific detail of someone else's costume. At least two other guests must raise a glass. No drinking required." },
  },
  {
    r1: { title: 'So decreed', text: 'Invent a harmless fictional law for the monster kingdom. Get two guests to approve it by saying "so decreed." It must not require any real party behaviour.' },
    r2: { title: 'The catchphrase coach', text: "Get a guest to invent a catchphrase for another guest's character. Persuade that second guest to perform the line in character." },
  },
  {
    r1: { title: 'Formal introductions', text: 'Introduce two guests to each other using invented supernatural titles, even if they already know each other. Get both to greet the other by their new title.' },
    r2: { title: 'Your next adventure', text: 'Get two guests to agree on an imaginary side quest for your character, then invent a ridiculous reward for completing it.' },
  },
  {
    r1: { title: 'A tiny prophecy', text: "Get a guest to invent a ridiculous prophecy for someone else's character. Then get the recipient to explain how they plan to fulfil or avoid it." },
    r2: { title: 'Pass it on', text: 'Get one guest to teach a signature character gesture to another guest. Watch the second guest perform it. No touching is needed.' },
  },
  {
    r1: { title: 'Hidden details', text: 'Ask two guests to point out an easily missed detail of their own costume. Tell a third guest about both details.' },
    r2: { title: 'An unlikely alliance', text: 'Persuade two guests whose characters seem unlikely allies to invent a team name together and announce it with a shared dramatic pose.' },
  },
  {
    r1: { title: 'The dream team', text: 'Ask two guests which two characters here would make the best team for a fictional haunted-bank heist. Get them to agree on one pair.' },
    r2: { title: 'Questionable decisions', text: 'Get someone else to include the exact words "to questionable decisions" in a toast. At least two other guests must raise a glass. No drinking required.' },
  },
  {
    r1: { title: 'Royal protection', text: 'Persuade a guest to act as your ceremonial bodyguard for 10 seconds. Afterwards, thank them aloud with an invented official title. No physical contact is needed.' },
    r2: { title: 'Borrowed backstories', text: "Get two guests to invent a one-sentence origin story for each other's costume. Both must say their story aloud to the other." },
  },
  {
    r1: { title: 'Haunted reviews', text: 'Get two guests to each deliver a short review of an imaginary haunted hotel, including a star rating and one ridiculous complaint.' },
    r2: { title: 'The royal wave', text: 'Show two guests two different royal waves. Get them to agree which is better, then have both perform the winning wave.' },
  },
  {
    r1: { title: 'A party that never was', text: 'With a guest, invent a clearly fictional story about a previous monster party. Get that guest to retell your invented story to a third person.' },
    r2: { title: 'Roommate material', text: 'Get two guests to debate which character here would make the best haunted-house roommate. Each must give a choice and a reason.' },
  },
  {
    r1: { title: 'The costume court', text: 'Start a playful debate with a guest about which of your characters would make the better secret agent. Recruit a third guest to hear both arguments and judge.' },
    r2: { title: 'An official appointment', text: 'Get a guest to appoint your character to a silly party job. Get a different guest to ask you to perform one harmless pretend duty. Do not touch belongings.' },
  },
  {
    r1: { title: 'The secret greeting', text: 'Invent a short, touch-free greeting with another guest. Get a third guest to learn it and exchange it with you.' },
    r2: { title: 'The weather report', text: "Get a guest to describe someone else's costume as a weather forecast. Ask the costume wearer to invent a matching weather warning." },
  },
  {
    r1: { title: 'Character shopping', text: 'Ask two different guests to recommend an imaginary item your character needs. Each must name an item and explain why.' },
    r2: { title: 'The imaginary awards', text: 'Get one guest to invent a ridiculous award for another. Have the recipient accept or reject it with an explanation. No speech or audience needed.' },
  },
];

export const MISSION_RULES =
  "Guests named in a task are other players unless the card includes you. Ask directly or bluff about your motive, but don't show your screen, announce the objective, or offer votes. If someone declines, ask someone else. Success means the whole task, on honour.";
