import { Redis } from '@upstash/redis';
import type { Meta, Player } from './types';

// Works with either env naming: Upstash's own, or Vercel's Marketplace integration (KV_*).
const url = process.env.UPSTASH_REDIS_REST_URL || process.env.KV_REST_API_URL;
const token = process.env.UPSTASH_REDIS_REST_TOKEN || process.env.KV_REST_API_TOKEN;
const redis = url && token ? new Redis({ url, token }) : null;

export const storageMode: 'redis' | 'memory' = redis ? 'redis' : 'memory';

const TTL = 60 * 60 * 72; // games expire after 3 days

type Mem = { meta: Map<string, string>; players: Map<string, Map<string, string>> };
const g = globalThis as unknown as { __hollowCrown?: Mem };
const mem: Mem = g.__hollowCrown ?? (g.__hollowCrown = { meta: new Map(), players: new Map() });

const mk = (c: string) => `hc:${c}:meta`;
const pk = (c: string) => `hc:${c}:players`;

function parse<T>(v: unknown): T | null {
  if (v == null) return null;
  if (typeof v === 'string') {
    try {
      return JSON.parse(v) as T;
    } catch {
      return null;
    }
  }
  return v as T;
}

export async function loadGame(code: string): Promise<{ meta: Meta | null; players: Player[] }> {
  if (redis) {
    const pipe = redis.pipeline();
    pipe.get(mk(code));
    pipe.hgetall(pk(code));
    const [m, ps] = (await pipe.exec()) as [unknown, Record<string, unknown> | null];
    const meta = parse<Meta>(m);
    const players = ps
      ? Object.values(ps)
          .map((v) => parse<Player>(v))
          .filter((p): p is Player => !!p)
      : [];
    return { meta, players };
  }
  const m = mem.meta.get(code);
  const ps = mem.players.get(code);
  return {
    meta: m ? (JSON.parse(m) as Meta) : null,
    players: ps ? [...ps.values()].map((v) => JSON.parse(v) as Player) : [],
  };
}

export async function gameExists(code: string): Promise<boolean> {
  if (redis) return (await redis.exists(mk(code))) === 1;
  return mem.meta.has(code);
}

export async function saveMeta(meta: Meta): Promise<void> {
  if (redis) {
    await redis.set(mk(meta.code), JSON.stringify(meta), { ex: TTL });
    return;
  }
  mem.meta.set(meta.code, JSON.stringify(meta));
}

export async function savePlayers(code: string, players: Player[]): Promise<void> {
  if (!players.length) return;
  if (redis) {
    const obj: Record<string, string> = {};
    for (const p of players) obj[p.id] = JSON.stringify(p);
    const pipe = redis.pipeline();
    pipe.hset(pk(code), obj);
    pipe.expire(pk(code), TTL);
    await pipe.exec();
    return;
  }
  let map = mem.players.get(code);
  if (!map) mem.players.set(code, (map = new Map()));
  for (const p of players) map.set(p.id, JSON.stringify(p));
}

export async function removePlayer(code: string, id: string): Promise<void> {
  if (redis) {
    await redis.hdel(pk(code), id);
    return;
  }
  mem.players.get(code)?.delete(id);
}
