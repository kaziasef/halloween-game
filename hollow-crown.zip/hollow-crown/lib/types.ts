import type { Mission } from './missions';

export type Phase =
  | 'lobby'
  | 'round1'
  | 'midpoint'
  | 'round2'
  | 'finale'
  | 'nominate'
  | 'runoff'
  | 'suspects'
  | 'reveal'
  | 'vote'
  | 'costumeRunoff'
  | 'results';

export type Role = 'monster' | 'hunter';
export type Faction = 'monsters' | 'hunters';

export interface Meta {
  code: string;
  hostToken: string;
  createdAt: number;
  phase: Phase;
  phaseStartedAt: number;
  hunters: number;
  threshold: number;
  midpointCurses: number | null;
  finaleCurses: number | null;
  discussionEndsAt: number | null;
  suspects: string[] | null;
  runoff: { candidates: string[]; slots: number; chosen: string[] } | null;
  winner: Faction | null;
  costumeTally: Record<string, number> | null;
  costumeRunoff: string[] | null;
  crowned: string | null;
  notes: string[];
}

export interface Player {
  id: string;
  token: string;
  name: string;
  costume: string;
  joinedAt: number;
  role: Role | null;
  pair: number | null;
  m1Done: boolean;
  m1Guests: string;
  m2Done: boolean;
  m2Guests: string;
  sealed1: boolean;
  sealed2: boolean;
  reading: { target: string; role: Role } | null;
  nominations: string[] | null;
  runoffPicks: string[] | null;
  costumeVotes: Record<string, number> | null;
  costumeRunoffPick: string | null;
}

export interface PublicPlayer {
  id: string;
  name: string;
  costume: string;
  inGame: boolean;
}

export interface RevealRow {
  id: string;
  role: Role;
  missions: number;
}

export interface PublicState {
  code: string;
  phase: Phase;
  phaseStartedAt: number;
  serverNow: number;
  players: PublicPlayer[];
  inGameCount: number;
  hunters: number;
  threshold: number;
  midpointCurses: number | null;
  finaleCurses: number | null;
  discussionEndsAt: number | null;
  suspects: string[] | null;
  runoff: { candidates: string[]; slots: number; chosen: string[] } | null;
  winner: Faction | null;
  costumeTally: Record<string, number> | null;
  costumeRunoff: string[] | null;
  crowned: string | null;
  notes: string[];
  reveal: RevealRow[] | null;
  _clientAt?: number;
}

export interface MeView {
  id: string;
  name: string;
  costume: string;
  role: Role | null;
  pair: number | null;
  r1: Mission | null;
  r2: Mission | null;
  m1Done: boolean;
  m1Guests: string;
  m2Done: boolean;
  m2Guests: string;
  sealed1: boolean;
  sealed2: boolean;
  reading: { targetId: string; targetName: string; role: Role } | null;
  firstEarned: boolean;
  secondEarned: boolean;
  voteAllowance: number | null;
  nominations: string[] | null;
  runoffPicks: string[] | null;
  costumeVotes: Record<string, number> | null;
  costumeRunoffPick: string | null;
  can: { m1: boolean; m2: boolean; seal1: boolean; seal2: boolean; reading: boolean };
}

export interface PlayerView extends PublicState {
  me: MeView;
}

export interface HostView extends PublicState {
  storage: 'redis' | 'memory';
  counts: {
    sealed1: number;
    sealed2: number;
    nominated: number;
    runoffPicked: number;
    voted: number;
    costumeRunoffPicked: number;
  };
}
